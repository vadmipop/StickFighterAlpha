# FinalProject_3110

This is our final project for 3110, final realease.

It can be run with "make play" after following the installation instruction in INSTALL.md.

A full list of moves can be found in data/moves/move_list.txt